#!/usr/bin/env python3

from alchemy import elements

if __name__ == "__main__":
    print("=== Alembic 5 ===")
    print("Accessing the alchemy module using 'from alchemy import ...'")
    print("Testing create_air: ", elements.create_air())
    print()
