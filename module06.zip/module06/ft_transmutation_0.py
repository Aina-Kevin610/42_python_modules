#!/usr/bin/env python3

import alchemy.transmutation.recipes

if __name__ == "__main__":
    print("=== transmutation 0 ===")
    print(alchemy.transmutation.recipes.lead_to_gold())
