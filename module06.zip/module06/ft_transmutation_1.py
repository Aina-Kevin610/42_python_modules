#!/usr/bin/env python3

import alchemy.transmutation

if __name__ == "__main__":
    print("=== Transmutation 1 ===")
    print(alchemy.transmutation.lead_to_gold())
    print()
